// Function to handle form submission for patient information
function handleSubmit(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const gender = document.getElementById('gender').value;
    const dob = document.getElementById('dob').value;
    const email = document.getElementById('email').value;
    const prescriptions = document.getElementById('prescriptions').value;
    const medicines = document.getElementById('medicines').value;

    const patient = {
        name,
        gender,
        dob,
        email,
        prescriptions,
        medicines
    };

    localStorage.setItem('patientData', JSON.stringify(patient));
    window.location.href = 'display.html';
}

// Function to handle viewing patient records
function handleViewRecords() {
    window.location.href = 'display.html';
}

document.getElementById('patientForm').addEventListener('submit', handleSubmit);
document.getElementById('viewRecords').addEventListener('click', handleViewRecords);